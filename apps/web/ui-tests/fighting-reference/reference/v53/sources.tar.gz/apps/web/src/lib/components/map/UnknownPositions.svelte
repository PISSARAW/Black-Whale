<script lang="ts">
  import { page } from '$app/stores'
  import { mapState } from '$lib/state/mapState.svelte'
  import { displayName } from '$lib/utils/displayNames'
  import { locale, t } from '$lib/i18n'

  interface MapLocation {
    id: string
    type: string
  }
  interface MapBody {
    id: string
    originalCharacterId: string | null
  }
  interface MapCharacter {
    id: string
    canonicalName: string
  }
  interface MapPresence {
    entityId: string
    locationId: string | null
  }

  let unknownCharacters = $derived.by(() => {
    const worldState = $page.data.worldState
    const locations = new Map<string, MapLocation>(
      (($page.data.locations || worldState?.locations || []) as MapLocation[]).map((location) => [
        location.id,
        location,
      ]),
    )
    const bodies = (worldState?.bodies || []) as MapBody[]
    const characters = (worldState?.characters || []) as MapCharacter[]

    return ((worldState?.presences || []) as MapPresence[])
      .filter((presence) => {
        const location = presence.locationId ? locations.get(presence.locationId) : null
        return !location || location.type === 'UNKNOWN'
      })
      .map((presence) => {
        const body = bodies.find((candidate) => candidate.id === presence.entityId)
        const character = body
          ? characters.find((candidate) => candidate.id === body.originalCharacterId)
          : null

        return {
          id: presence.entityId,
          label: character
            ? displayName(character.canonicalName, $locale)
            : $t.map.unidentifiedIndividual,
          // A boolean rather than the rendered label, so the count below does
          // not depend on the active language.
          identified: Boolean(character),
        }
      })
  })

  let identifiedCount = $derived(
    unknownCharacters.filter((character) => character.identified).length,
  )
</script>

{#if mapState.filters.showUnknownPositions}
  <div
    class="absolute bottom-4 left-4 z-40 flex max-h-[min(38rem,calc(100%-2rem))] w-80 max-w-[calc(100%-2rem)] flex-col rounded-lg border border-gray-700 bg-[#1a1a1a] p-4 text-[#FFFFF0] shadow-lg"
  >
    <div class="mb-3 flex items-center justify-between border-b border-gray-700 pb-2">
      <h3 class="text-sm font-bold tracking-wider text-gray-400 uppercase">
        {$t.mapUi.unknownLocationTitle}
      </h3>
      <button
        type="button"
        onclick={() => (mapState.filters.showUnknownPositions = false)}
        class="grid h-11 w-11 shrink-0 place-items-center text-gray-500 hover:text-white"
        aria-label={$t.mapUi.closeUnknownPositions}>✕</button
      >
    </div>

    <div class="mb-3 space-y-1 rounded border border-gray-700 bg-[#121212] p-2 text-xs">
      <p>{$t.mapUi.bodiesWithoutLocation(unknownCharacters.length)}</p>
      <p>
        {$t.mapUi.identifiedSplit(identifiedCount, unknownCharacters.length - identifiedCount)}
      </p>
    </div>

    {#if unknownCharacters.length > 0}
      <ul class="min-h-0 space-y-2 overflow-y-auto pr-1 text-sm">
        {#each unknownCharacters as character (character.id)}
          <li class="flex items-center text-gray-300">
            <span class="mr-2 h-2 w-2 rounded-full bg-gray-500"></span>
            <span>{character.label}</span>
            <span class="ml-2 text-xs text-gray-500"
              >{character.identified ? $t.map.knownIdentity : $t.map.unknownIdentity}</span
            >
          </li>
        {/each}
      </ul>
    {:else}
      <p class="text-sm text-gray-400">{$t.mapUi.everyBodyMapped}</p>
    {/if}
  </div>
{/if}
