<script lang="ts">
  /**
   * Tier 3-C, generated from `data/ship/blueprint.json`.
   *
   * The authored plan uses a 1000 x 600 coordinate frame at 0.35 m per unit,
   * with the ship's midpoint at (500, 300). Every tier uses the same landscape
   * frame; the walkthrough geometry remains in the shared ship axes.
   * Every room in the blueprint is drawn rather than leaving unnamed deck.
   *
   * Rooms the catalogue has a record for are clickable and zoom into their own
   * plan. Corridors and the spaces the reconstruction invented to keep the deck
   * contiguous are drawn dimmer and are not: there is nothing to open.
   *
   * Do not hand-edit — regenerate from the blueprint and annotations.
   */
  import { mapState } from '$lib/state/mapState.svelte'

  type Region = {
    id: string
    region: string | null
    points: string
    label: string
    size: number
    at: [number, number]
    turned: boolean
    through: boolean
    inferred: boolean
  }

  const regions: Region[] = [
    {
      id: 'tier-3-c-central-spine',
      region: null,
      points: '360.0,270.0 400.0,270.0 400.0,470.0 360.0,470.0',
      label: 'Central Spine',
      size: 12,
      at: [380.0, 374.0],
      turned: true,
      through: true,
      inferred: true,
    },
    {
      id: 'tier-3-residential-standard',
      region: 't3-residential-ord',
      points: '180.0,270.0 360.0,270.0 360.0,470.0 180.0,470.0',
      label: 'Standard Residential Block',
      size: 12,
      at: [270.0, 374.0],
      turned: false,
      through: false,
      inferred: false,
    },
  ]

  function select(regionId: string | null) {
    if (regionId) mapState.selectLocation(regionId)
  }

  function selectWithKeyboard(event: KeyboardEvent, regionId: string | null) {
    if (event.key !== 'Enter' && event.key !== ' ') return
    event.preventDefault()
    event.stopPropagation()
    select(regionId)
  }
</script>

<svg viewBox="0 0 1000 600" class="w-full h-full text-[#FFFFF0]">
  <defs>
    <style>
      .hull {
        fill: #1a0f0f;
        stroke: #ffd700;
        stroke-width: 4;
      }
      .zone {
        fill: #2a1515;
        stroke: #fffff0;
        stroke-width: 1.5;
        transition: fill 0.2s;
      }
      .zone.clickable {
        cursor: pointer;
      }
      .zone.clickable:hover {
        fill: #3d1c1c;
      }
      .zone.selected {
        stroke: #ffd700;
        stroke-width: 2.5;
        fill: #4d2020;
      }
      .zone.through {
        fill: #150b0b;
        stroke: #ffd700;
        stroke-opacity: 0.35;
        stroke-width: 1;
        stroke-dasharray: 4 4;
      }
      .zone.inferred {
        fill: #16171c;
        stroke: #9dc4e0;
        stroke-opacity: 0.4;
      }
      .label {
        fill: #fffff0;
        font-family: sans-serif;
        pointer-events: none;
        text-anchor: middle;
      }
    </style>
  </defs>

  <polygon
    class="hull"
    points="120.0,50.0 90.31,64.0 67.2,102.0 50.71,158.0 40.8,226.0 37.51,300.0 40.8,374.0 50.71,442.0 67.2,498.0 90.31,536.0 120.0,550.0 850.0,550.0 885.11,536.0 912.4,498.0 931.89,442.0 943.6,374.0 947.51,300.0 943.6,226.0 931.91,158.0 912.4,102.0 885.11,64.0 850.0,50.0"
  />

  <g id="tier-3-c-zones">
    {#each regions as zone (zone.id)}
      {#if zone.region}
        <g
          role="button"
          tabindex="0"
          aria-label={`Open ${zone.label || zone.id}`}
          onclick={() => select(zone.region)}
          onkeydown={(event) => selectWithKeyboard(event, zone.region)}
        >
          <polygon
            class="zone clickable"
            class:through={zone.through}
            class:inferred={zone.inferred}
            class:selected={mapState.selectedLocationId === zone.region}
            points={zone.points}
          />
        </g>
      {:else}
        <polygon
          class="zone"
          class:through={zone.through}
          class:inferred={zone.inferred}
          points={zone.points}
        />
      {/if}
    {/each}

    {#each regions.filter((zone) => zone.size > 0) as zone (zone.id)}
      <text
        class="label"
        x={zone.at[0]}
        y={zone.at[1]}
        font-size={zone.size}
        transform={zone.turned ? `rotate(-90 ${zone.at[0]} ${zone.at[1]})` : ''}>{zone.label}</text
      >
    {/each}
  </g>
</svg>
