import { readAura } from '../combat/perception'
import { STRIKE_RANGE } from '../combat/resolve'
import { combatReducer } from '../combat/reducer'
import { BODY_ZONES, type BodyZone, type CombatState } from '../combat/types'

const THINK_EVERY = 0.45
export type ArenaDifficulty = 'initiate' | 'fighter' | 'master'
export const DIFFICULTY_CADENCE: Record<ArenaDifficulty, number> = {
  initiate: 0.68,
  fighter: THINK_EVERY,
  master: 0.3,
}

export type OpponentDoctrine = 'counter' | 'binder' | 'artillery' | 'deceiver'

export const OPPONENT_DOCTRINES: Record<
  OpponentDoctrine,
  { name: string; hatsu: 'enhance' | 'bind' | 'barrage' }
> = {
  counter: { name: 'Le Contreur', hatsu: 'enhance' },
  binder: { name: "L'Entraveuse", hatsu: 'bind' },
  artillery: { name: "L'Artilleur", hatsu: 'barrage' },
  deceiver: { name: 'Le Trompeur', hatsu: 'enhance' },
}

/** Who the opponent is and how sharply it plays. Both have defaults. */
export interface ArenaOpponentOptions {
  doctrine?: OpponentDoctrine
  difficulty?: ArenaDifficulty
}

export function advanceArena(
  state: CombatState,
  dt: number,
  { doctrine = 'counter', difficulty = 'fighter' }: ArenaOpponentOptions = {},
): CombatState {
  const ticked = rememberObservedStrike(combatReducer(state, { type: 'TICK', dt }))
  if (ticked.outcome !== 'playing') return ticked
  const cadence = DIFFICULTY_CADENCE[difficulty]
  if (Math.floor(ticked.clock / cadence) === Math.floor(state.clock / cadence)) return ticked
  return decide(ticked, doctrine, cadence)
}

function decide(state: CombatState, doctrine: OpponentDoctrine, cadence: number): CombatState {
  const ai = state.opponent
  if (ai.condition !== 'ready') return state
  if (ai.intent) return state
  if (state.player.condition !== 'ready') {
    return combatReducer(state, { type: 'MOVE', side: 'opponent', vector: [0, 0] })
  }

  const delta = [
    state.player.position[0] - ai.position[0],
    state.player.position[1] - ai.position[1],
  ] as const
  const gap = Math.hypot(delta[0], delta[1])
  if (shouldCastHatsu(state, doctrine, gap)) {
    const reading = readAura(state.opponent, state.player)
    return combatReducer(state, {
      type: 'HATSU',
      side: 'opponent',
      effect: OPPONENT_DOCTRINES[doctrine].hatsu,
      zone: openZone(reading.guard, Math.floor(state.clock / THINK_EVERY)),
    })
  }
  if (gap > STRIKE_RANGE - 0.2) {
    const weave = Math.floor(state.clock / 2) % 2 === 0 ? 0.42 : -0.42
    return combatReducer(state, {
      type: 'MOVE',
      side: 'opponent',
      vector: [delta[0] - delta[1] * weave, delta[1] + delta[0] * weave],
    })
  }

  let current = combatReducer(state, { type: 'MOVE', side: 'opponent', vector: [0, 0] })
  const playerReading = readAura(state.opponent, state.player)
  if (playerReading.feintZone) {
    current = combatReducer(current, {
      type: 'RYU',
      side: 'opponent',
      guard: playerReading.feintZone,
    })
    return combatReducer(current, { type: 'GUARD', side: 'opponent' })
  }
  if (state.player.ko) {
    return combatReducer(current, { type: 'KEN', side: 'opponent', on: true })
  }

  current = combatReducer(current, {
    type: 'GYO',
    side: 'opponent',
    on: current.opponent.aura > 24,
  })
  current = combatReducer(current, { type: 'MODE', side: 'opponent', mode: 'ren' })
  current = combatReducer(current, { type: 'KEN', side: 'opponent', on: false })
  const reading = readAura(current.opponent, current.player)
  const learned = learnedGuard(current)
  if (learned && Math.floor(current.clock / cadence) % 2 === 0) {
    current = combatReducer(current, { type: 'RYU', side: 'opponent', guard: learned })
  }
  const zone = openZone(reading.guard, Math.floor(current.clock / cadence))

  if (current.player.recoveryWindow <= 0 && Math.floor(current.clock / THINK_EVERY) % 4 === 0) {
    if (doctrine === 'deceiver') {
      current = combatReducer(current, { type: 'IN', side: 'opponent', on: true })
    }
    return combatReducer(current, { type: 'FEINT', side: 'opponent', zone })
  }

  if (current.opponent.aura >= 35 && current.clock % 3 < THINK_EVERY) {
    return combatReducer(current, { type: 'KO', side: 'opponent', zone })
  }
  const hidden =
    doctrine === 'deceiver' ||
    (Math.floor(current.clock / THINK_EVERY) % 6 === 3 && current.opponent.aura > 30)
  current = combatReducer(current, { type: 'IN', side: 'opponent', on: hidden })
  return combatReducer(current, { type: 'PREPARE_STRIKE', side: 'opponent', zone })
}

function rememberObservedStrike(state: CombatState): CombatState {
  const event = state.lastEvent
  if (!event || event.attacker !== 'player' || event.at === state.opponentMemory.observedEventAt)
    return state
  const concealed = state.player.in && !state.opponent.gyo
  const zones = concealed
    ? state.opponentMemory.zones
    : {
        ...state.opponentMemory.zones,
        [event.zone]: state.opponentMemory.zones[event.zone] + 1,
      }
  const ranked = BODY_ZONES.map((zone) => [zone, zones[zone]] as const).sort(
    (left, right) => right[1] - left[1],
  )
  const observations = Object.values(zones).reduce((sum, count) => sum + count, 0)
  const visibleHatsu =
    state.lastHatsuBySide.player && !state.player.in ? state.lastHatsuBySide.player : null
  return {
    ...state,
    opponentMemory: {
      observedEventAt: event.at,
      zones,
      hypothesis: {
        preferredZone: observations > 0 ? ranked[0][0] : null,
        confidence: observations > 0 ? ranked[0][1] / observations : 0,
        concealedAttacks: state.opponentMemory.hypothesis.concealedAttacks + Number(concealed),
        knownHatsuIds: visibleHatsu
          ? [...new Set([...state.opponentMemory.hypothesis.knownHatsuIds, visibleHatsu])]
          : state.opponentMemory.hypothesis.knownHatsuIds,
      },
    },
  }
}

function learnedGuard(state: CombatState): BodyZone | null {
  return state.opponentMemory.hypothesis.confidence >= 0.5
    ? state.opponentMemory.hypothesis.preferredZone
    : null
}

function shouldCastHatsu(state: CombatState, doctrine: OpponentDoctrine, gap: number): boolean {
  if (state.opponent.aura < 34 || Math.floor(state.clock / THINK_EVERY) % 7 !== 0) return false
  if (doctrine === 'binder') return gap <= 7 && state.player.bound <= 0
  if (doctrine === 'artillery') return gap > STRIKE_RANGE && gap <= 9
  return state.opponent.empowered <= 0
}

function openZone(guard: BodyZone | null, turn: number): BodyZone {
  const open = guard ? BODY_ZONES.filter((zone) => zone !== guard) : BODY_ZONES
  return open[turn % open.length]
}
