<script lang="ts">
  // Room interactions are not wired up yet. The elements keep their click
  // and keyboard affordances so the behaviour can be attached in one place
  // when it exists; until then this must not log on a public page.
  function handleElementClick(_elementId: string) {}
</script>

<svg
  viewBox="0 0 800 600"
  class="w-full h-full text-[#FFFFF0] bg-[#050505] rounded-lg border border-[#333]"
>
  <defs>
    <style>
      .wall {
        stroke: #fffff0;
        stroke-width: 6;
        fill: none;
      }
      .zone {
        fill: rgba(255, 215, 0, 0.05);
        transition: fill 0.2s;
        cursor: pointer;
      }
      .zone:hover {
        fill: rgba(255, 215, 0, 0.15);
      }
      .label {
        fill: #fffff0;
        font-family: sans-serif;
        font-size: 16px;
        font-weight: bold;
        pointer-events: none;
        text-anchor: middle;
      }
      .sublabel {
        fill: #ffd700;
        font-size: 12px;
        pointer-events: none;
        text-anchor: middle;
      }
      .furniture {
        fill: #222;
        stroke: #666;
        stroke-width: 3;
      }
    </style>
  </defs>

  <text x="400" y="40" class="label" font-size="28" fill="#FFD700">Tribunal Central</text>

  <g transform="translate(50, 80)">
    <!-- Room Walls -->
    <rect x="0" y="0" width="700" height="500" class="wall" />

    <!-- Judge's Dais (Top) -->
    <rect
      role="button"
      tabindex="0"
      aria-label="Inspect map area"
      onkeydown={(event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault()
          event.currentTarget.dispatchEvent(new MouseEvent('click', { bubbles: true }))
        }
      }}
      class="zone"
      x="200"
      y="0"
      width="300"
      height="200"
      onclick={() => handleElementClick('judges-bench')}
    />
    <rect x="220" y="120" width="260" height="60" class="furniture" />
    <!-- Bench -->

    <rect x="310" y="20" width="80" height="100" class="furniture" />
    <text x="350" y="160" class="label text-white">Magistrate's Seat</text>

    <!-- Clerk's Desk (Right) -->
    <rect x="550" y="180" width="100" height="60" class="furniture" />
    <circle cx="600" cy="160" r="12" fill="#ddd" />
    <text x="600" y="220" class="sublabel">Clerks</text>

    <!-- Defendant's Stand (Center) -->
    <rect
      role="button"
      tabindex="0"
      aria-label="Inspect map area"
      onkeydown={(event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault()
          event.currentTarget.dispatchEvent(new MouseEvent('click', { bubbles: true }))
        }
      }}
      class="zone"
      x="300"
      y="300"
      width="100"
      height="100"
      onclick={() => handleElementClick('defendant-stand')}
    />
    <rect x="310" y="310" width="80" height="40" class="furniture" />
    <circle cx="350" cy="370" r="12" fill="#ddd" />
    <!-- Defendant -->
    <line x1="335" y1="380" x2="365" y2="380" stroke="#fff" stroke-width="2" />
    <!-- Hands bound -->
    <text x="350" y="340" class="label text-gray-400">Defendant</text>

    <!-- Armed Guards -->
    <circle cx="150" cy="350" r="15" fill="#4a5568" />
    <!-- Guard Left -->
    <line x1="150" y1="320" x2="160" y2="280" stroke="#111" stroke-width="4" />
    <!-- Rifle -->

    <circle cx="550" cy="350" r="15" fill="#4a5568" />
    <!-- Guard Right -->
    <line x1="550" y1="320" x2="540" y2="280" stroke="#111" stroke-width="4" />
    <!-- Rifle -->

    <text x="150" y="385" class="sublabel text-gray-500">Kakin Army</text>
    <text x="550" y="385" class="sublabel text-gray-500">Kakin Army</text>

    <!-- Prosecutor / Attorney (Front right) -->
    <circle cx="500" cy="450" r="12" fill="#ddd" />
    <rect x="490" y="470" width="20" height="10" fill="#fff" />
    <!-- Document -->
    <text x="500" y="495" class="sublabel">Prosecutor</text>
  </g>
</svg>
