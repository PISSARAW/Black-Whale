<script lang="ts">
  import { link } from '$lib/i18n'
  import type { HuntHatsuId, HuntHatsuProfile } from '$lib/hunt/hatsu'
  import type { HunterProfile, HunterProfileId } from '$lib/hunt/hunter/profiles'
  import type { HuntTerrain, HuntTerrainId } from '$lib/hunt/arena'
  import type { HuntContractV3 } from '$lib/hunt/contracts/types'
  import type { HuntVow } from '$lib/hunt/nen/advanced'

  interface Props {
    labels: {
      eyebrow: string
      title: string
      premise: string
      rule: string
      objective: string
      begin: string
      hatsu: string
      hatsuRule: string
      chooseHatsu: string
      role: Record<HuntHatsuProfile['role'], string>
    }
    profiles: HuntHatsuProfile[]
    selected: HuntHatsuId
    onSelect: (id: HuntHatsuId) => void
    hunterProfiles: HunterProfile[]
    selectedHunter: HunterProfileId
    hunterLabels: { choose: string; role: Record<HunterProfileId, string> }
    onSelectHunter: (id: HunterProfileId) => void
    terrains: HuntTerrain[]
    selectedTerrain: HuntTerrainId
    terrainLabel: string
    locale: string
    onSelectTerrain: (id: HuntTerrainId) => void
    contracts: HuntContractV3[]
    selectedContract: string
    contractLabel: string
    onSelectContract: (id: string) => void
    selectedVow: HuntVow | null
    onSelectVow: (vow: HuntVow | null) => void
    onBegin: () => void
  }

  let {
    labels,
    profiles,
    selected,
    onSelect,
    hunterProfiles,
    selectedHunter,
    hunterLabels,
    onSelectHunter,
    terrains,
    selectedTerrain,
    terrainLabel,
    locale,
    onSelectTerrain,
    contracts,
    selectedContract,
    contractLabel,
    onSelectContract,
    selectedVow,
    onSelectVow,
    onBegin,
  }: Props = $props()
</script>

<section class="hunt-briefing-overlay" aria-labelledby="hunt-briefing-title">
  <div class="hunt-briefing archive-page-heading">
    <h1 id="hunt-briefing-title" class="mt-4 text-3xl font-medium text-white sm:text-4xl">
      {labels.title}
    </h1>
    <p class="mx-auto mt-5 max-w-md text-base leading-relaxed text-white/70">{labels.premise}</p>
    <p
      class="mx-auto mt-4 max-w-md border-y border-white/10 py-4 text-sm leading-relaxed text-rose-200/90"
    >
      {labels.rule}
    </p>
    <p class="mt-4 text-sm text-white/55">{labels.objective}</p>
    <div class="mx-auto mt-6 max-w-lg">
      <p class="text-[0.65rem] uppercase tracking-normal text-amber-300/70">
        {contractLabel}
      </p>
      <div class="mt-2 grid gap-2 sm:grid-cols-2">
        {#each contracts as contract (contract.id)}
          <button
            class="rounded-sm border p-3 text-left transition {selectedContract === contract.id
              ? 'border-amber-300 bg-amber-300/10'
              : 'border-white/10 bg-white/[0.03]'}"
            aria-pressed={selectedContract === contract.id}
            onclick={() => onSelectContract(contract.id)}
          >
            <span class="block text-sm font-medium text-amber-100">
              {locale === 'fr' ? contract.title.fr : contract.title.en}
            </span>
            <span class="mt-1 block text-[0.65rem] leading-snug text-white/40">
              {locale === 'fr' ? contract.description.fr : contract.description.en}
            </span>
          </button>
        {/each}
      </div>
      <a
        class="mt-2 inline-block text-xs text-amber-200/65 underline underline-offset-4"
        href={$link('/hunt/editor')}
      >
        {locale === 'fr' ? 'Créer et partager un contrat' : 'Create and share a contract'}
      </a>
      <p class="text-[0.65rem] uppercase tracking-normal text-violet-300/70">
        {labels.chooseHatsu}
      </p>
      <div class="mt-2 grid gap-2 sm:grid-cols-3">
        {#each profiles as profile (profile.id)}
          <button
            class="rounded-sm border p-3 text-left transition {selected === profile.id
              ? 'border-violet-300 bg-violet-300/10'
              : 'border-white/10 bg-white/[0.03]'}"
            aria-pressed={selected === profile.id}
            onclick={() => onSelect(profile.id)}
          >
            <span class="block text-sm font-medium text-violet-100">{profile.name}</span>
            <span class="mt-1 block text-[0.65rem] uppercase tracking-wider text-white/40">
              {labels.role[profile.role]}
            </span>
          </button>
        {/each}
      </div>
      <details class="tour-disclosure mt-4">
        <summary>{locale === 'fr' ? 'Réglages de la traque' : 'Hunt settings'}</summary>
        <p class="mt-5 text-[0.65rem] uppercase tracking-normal text-amber-300/70">
          {locale === 'fr' ? 'Vœu optionnel' : 'Optional vow'}
        </p>
        <div class="mt-2 grid grid-cols-3 gap-2">
          {#each [{ id: null, en: 'None', fr: 'Aucun' }, { id: 'silent-hunt', en: 'Silent Hunt', fr: 'Traque silencieuse' }, { id: 'no-retreat', en: 'No retreat', fr: 'Sans retraite' }] as vow (vow.id)}
            <button
              class="rounded-sm border p-2 text-xs transition {selectedVow === vow.id
                ? 'border-amber-300 bg-amber-300/10 text-white'
                : 'border-white/10 text-white/50'}"
              aria-pressed={selectedVow === vow.id}
              onclick={() => onSelectVow(vow.id as HuntVow | null)}
              >{locale === 'fr' ? vow.fr : vow.en}</button
            >
          {/each}
        </div>
        <p class="mt-5 text-[0.65rem] uppercase tracking-normal text-sky-300/70">
          {terrainLabel}
        </p>
        <div class="mt-2 grid gap-2 sm:grid-cols-3">
          {#each terrains as terrain (terrain.id)}
            <button
              class="rounded-sm border p-3 text-left transition {selectedTerrain === terrain.id
                ? 'border-sky-300 bg-sky-300/10'
                : 'border-white/10 bg-white/[0.03]'}"
              aria-pressed={selectedTerrain === terrain.id}
              onclick={() => onSelectTerrain(terrain.id)}
            >
              <span class="block text-sm font-medium text-sky-100">
                {locale === 'fr' ? terrain.name.fr : terrain.name.en}
              </span>
              <span class="mt-1 block text-[0.65rem] leading-snug text-white/40">
                {locale === 'fr' ? terrain.description.fr : terrain.description.en}
              </span>
            </button>
          {/each}
        </div>
        <p class="mt-2 text-xs leading-relaxed text-white/45">{labels.hatsuRule}</p>
        <p class="mt-5 text-[0.65rem] uppercase tracking-normal text-rose-300/70">
          {hunterLabels.choose}
        </p>
        <div class="mt-2 grid gap-2 sm:grid-cols-3">
          {#each hunterProfiles as profile (profile.id)}
            <button
              class="rounded-sm border p-3 text-left transition {selectedHunter === profile.id
                ? 'border-rose-300 bg-rose-300/10'
                : 'border-white/10 bg-white/[0.03]'}"
              aria-pressed={selectedHunter === profile.id}
              onclick={() => onSelectHunter(profile.id)}
            >
              <span class="block text-sm font-medium capitalize text-rose-100">{profile.id}</span>
              <span class="mt-1 block text-[0.65rem] leading-snug text-white/40">
                {hunterLabels.role[profile.id]}
              </span>
            </button>
          {/each}
        </div>
      </details>
    </div>
    <button
      class="mt-8 rounded-full border border-sky-300/60 bg-sky-300/10 px-7 py-3 text-sm uppercase tracking-widest text-sky-100 transition hover:bg-sky-300/20"
      onclick={onBegin}>{labels.begin}</button
    >
  </div>
</section>

<style>
  .hunt-briefing-overlay {
    position: absolute;
    inset: 0;
    z-index: 90;
    display: flex;
    flex-direction: column;
    align-items: center;
    overflow-y: auto;
    overscroll-behavior: contain;
    background: #080b0c;
    padding: 1.5rem;
  }

  .hunt-briefing {
    flex: none;
    width: min(48rem, 100%);
    margin-block: auto;
    padding-block: 1.5rem;
    text-align: left;
  }
</style>
