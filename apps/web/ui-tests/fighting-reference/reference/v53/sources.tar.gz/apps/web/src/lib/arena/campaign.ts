import type { ArenaDifficulty, OpponentDoctrine } from './ai'
import type { ArenaProfile, NenMastery } from './profile'
import type { ArenaTerrainId } from './terrain'
import type { ArenaFormatId } from './formats'
import type { ArenaOpponentId } from './experience'
import type { ArenaReplay } from './replay/types'

export interface CampaignRequirement {
  challenge?: string
  mastery?: Partial<Record<NenMastery, number>>
}

export interface CampaignMission {
  id: string
  chapter: number
  titleFr: string
  titleEn: string
  challengeId: string
  doctrine: OpponentDoctrine
  difficulty: ArenaDifficulty
  terrainId: ArenaTerrainId
  formatId: ArenaFormatId
  opponentId: ArenaOpponentId
  boss?: boolean
  requires: CampaignRequirement
}

export const ARENA_CAMPAIGN: CampaignMission[] = [
  {
    id: 'initiation',
    chapter: 1,
    titleFr: 'Fondations',
    titleEn: 'Foundations',
    challengeId: 'ryu',
    doctrine: 'counter',
    difficulty: 'initiate',
    terrainId: 'tier-1-banquet-hall',
    formatId: 'first-to-three',
    opponentId: 'counter-student',
    requires: {},
  },
  {
    id: 'closed-guard',
    chapter: 1,
    titleFr: 'Garde fermée',
    titleEn: 'Closed Guard',
    challengeId: 'guard',
    doctrine: 'counter',
    difficulty: 'fighter',
    terrainId: 'tier-1-banquet-hall',
    formatId: 'first-to-three',
    opponentId: 'counter-student',
    requires: { challenge: 'ryu', mastery: { ryu: 3 } },
  },
  {
    id: 'hidden-aura',
    chapter: 2,
    titleFr: 'Aura cachée',
    titleEn: 'Hidden Aura',
    challengeId: 'in-gyo',
    doctrine: 'deceiver',
    difficulty: 'fighter',
    terrainId: 'tier-2-screening-room',
    formatId: 'first-to-three',
    opponentId: 'in-examiner',
    requires: { challenge: 'guard', mastery: { gyo: 1 } },
  },
  {
    id: 'punish-ko',
    chapter: 2,
    titleFr: 'Punir le risque',
    titleEn: 'Punish the Risk',
    challengeId: 'ko',
    doctrine: 'artillery',
    difficulty: 'master',
    terrainId: 'tier-2-screening-room',
    formatId: 'sudden-death',
    opponentId: 'silent-gunner',
    requires: { challenge: 'in-gyo', mastery: { ken: 1 } },
  },
  {
    ...{
      id: 'mastery-exam',
      chapter: 3,
      titleFr: 'Examen du maître',
      titleEn: "Master's Exam",
      challengeId: 'zetsu',
      doctrine: 'binder',
      difficulty: 'master',
      terrainId: 'tier-1-banquet-hall',
      formatId: 'forced-mastery',
      opponentId: 'aura-auditor',
      requires: { challenge: 'ko', mastery: { ren: 3, ryu: 5, zetsu: 2 } },
    },
    boss: true,
  },
]

export function missionStatus(
  mission: CampaignMission,
  profile: ArenaProfile,
): 'complete' | 'available' | 'locked' {
  if (profile.unlocked.includes(mission.challengeId)) return 'complete'
  return unmetRequirements(mission, profile).length === 0 ? 'available' : 'locked'
}

export function unmetRequirements(mission: CampaignMission, profile: ArenaProfile): string[] {
  const unmet: string[] = []
  if (mission.requires.challenge && !profile.unlocked.includes(mission.requires.challenge)) {
    unmet.push(`challenge:${mission.requires.challenge}`)
  }
  for (const [technique, minimum] of Object.entries(mission.requires.mastery ?? {})) {
    // `?? 0` keeps a missing count a lock rather than an unlock: NaN would
    // fail every comparison and read as "requirement met".
    if ((profile.mastery[technique as NenMastery] ?? 0) < (minimum ?? 0))
      unmet.push(`mastery:${technique}:${minimum}`)
  }
  return unmet
}

export function missionMatchesReplay(mission: CampaignMission, replay: ArenaReplay): boolean {
  return (
    replay.match.missionId === mission.id &&
    replay.match.challengeId === mission.challengeId &&
    replay.match.formatId === mission.formatId &&
    replay.match.opponentId === mission.opponentId &&
    replay.setup.terrain.id === mission.terrainId &&
    replay.doctrine === mission.doctrine &&
    replay.difficulty === mission.difficulty
  )
}
