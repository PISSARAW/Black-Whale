import {
  NEN_PRESENTATION,
  type NenTechnique,
  type NenTechniqueAction,
  type NenTechniqueState,
} from '@black-whale/nen-engine'
import { hatsuAudioGraph, type Graph } from './ambient'
import { applyNenPerception, releaseNenPerception } from './nen/perception'
import { emissionTarget } from './space'
import type { NenObjectInteraction } from '$lib/tour/NenSceneAura'

const LEAD = 0.012

interface Tone {
  from: number
  to: number
  peak: number
  duration: number
  type?: OscillatorType
}

function tone(g: Graph, at: number, sound: Tone) {
  const oscillator = g.context.createOscillator()
  oscillator.type = sound.type ?? 'sine'
  oscillator.frequency.setValueAtTime(sound.from, at)
  oscillator.frequency.exponentialRampToValueAtTime(Math.max(1, sound.to), at + sound.duration)
  const gain = g.context.createGain()
  gain.gain.setValueAtTime(0.0001, at)
  gain.gain.exponentialRampToValueAtTime(sound.peak, at + Math.min(0.045, sound.duration / 4))
  gain.gain.exponentialRampToValueAtTime(0.0001, at + sound.duration)
  oscillator.connect(gain)
  // Into the room as well as into the mixer: aura raised in the hold rings for
  // four seconds and in a cabin for half of one. The held sustain below stays
  // on the mixer alone — it outlives the room it was started in.
  gain.connect(emissionTarget(g))
  oscillator.start(at)
  oscillator.stop(at + sound.duration + 0.03)
}

function chord(g: Graph, notes: Tone[]) {
  const at = g.context.currentTime + LEAD
  notes.forEach((note, index) => tone(g, at + index * 0.018, note))
}

const ACTION_TECHNIQUE: Record<NenTechniqueAction['type'], NenTechnique> = {
  TEN: 'ten',
  REN: 'ren',
  ZETSU: 'zetsu',
  GYO: 'gyo',
  IN: 'in',
  EN: 'en',
  KEN: 'ken',
  KO: 'ko',
  RYU: 'ryu',
  SHU: 'shu',
  ON: 'on',
}

function activeTransition(action: NenTechniqueAction) {
  if ('on' in action) return action.on
  if (action.type === 'EN') return action.radius !== null
  if (action.type === 'KO') return action.zone !== null
  return true
}

/** The same abstract signature drives every Tour mode; only spatial gain may differ. */
function canonicalCue(g: Graph, technique: NenTechnique) {
  const profile = NEN_PRESENTATION[technique]
  const duration = Math.max(0.16, profile.envelope.attack + profile.envelope.release)
  const peak = 0.14 * profile.sound.volume
  chord(g, [
    {
      from: profile.sound.lowHz,
      to: Math.min(profile.sound.highHz, profile.sound.lowHz * 1.8),
      peak,
      duration,
      type: profile.sound.noise > 0.35 ? 'sawtooth' : 'triangle',
    },
    {
      from: profile.sound.highHz,
      to: Math.max(profile.sound.lowHz, profile.sound.highHz * 0.72),
      peak: peak * 0.46,
      duration: duration * 1.08,
      type: 'sine',
    },
  ])
}

/** Audible signature of a basic Nen transition. Zetsu gets only its closing hush. */
export function playNenTechniqueSound(action: NenTechniqueAction) {
  // Gyo already changes the surrounding mix while it is held. Its former
  // action cue stacked another pitched oscillator on top of the perception
  // bed, producing a sharp electronic beep on both mouse and keyboard use.
  if (action.type === 'GYO') return
  const g = hatsuAudioGraph()
  if (!g) return
  if (activeTransition(action)) return canonicalCue(g, ACTION_TECHNIQUE[action.type])
  switch (action.type) {
    case 'IN':
    case 'KEN':
    case 'SHU':
    case 'ON':
      chord(g, [{ from: 360, to: 90, peak: 0.012, duration: 0.16, type: 'triangle' }])
      return
    case 'EN':
    case 'KO':
      return
  }
}

export function playNenObjectSound(kind: NenObjectInteraction) {
  const g = hatsuAudioGraph()
  if (!g) return
  if (kind === 'strike') {
    chord(g, [
      { from: 118, to: 38, peak: 0.18, duration: 0.2, type: 'square' },
      { from: 460, to: 95, peak: 0.075, duration: 0.16, type: 'sawtooth' },
    ])
  } else if (kind === 'pressure') {
    chord(g, [{ from: 76, to: 46, peak: 0.13, duration: 0.55, type: 'sawtooth' }])
  } else if (kind === 'sense') {
    chord(g, [
      { from: 540, to: 1080, peak: 0.055, duration: 0.42 },
      { from: 810, to: 1320, peak: 0.025, duration: 0.5 },
    ])
  } else {
    chord(g, [{ from: 240, to: 420, peak: 0.05, duration: 0.3, type: 'triangle' }])
  }
}

/** Keeps the active principle audible without stacking a new AudioContext per mode. */
export function sustainNenSound(state: NenTechniqueState): () => void {
  const g = hatsuAudioGraph()
  if (!g || g.context.state !== 'running' || state.mode === 'zetsu') {
    // Zetsu is a state and not an absence of one: the world has to be *given
    // back*, which is what the release does. Same for a graph that will not
    // run — whatever the veil was left at has to open again.
    releaseNenPerception()
    return () => {}
  }
  // What the aura does to the rest of the mix rides on the same lifetime as the
  // held tone: the walk re-runs this on every change of state and tears the
  // last one down first. See `nen/perception.ts`.
  applyNenPerception(state, g)
  const technique: NenTechnique = state.on ? 'on' : state.ken ? 'ken' : state.en ? 'en' : state.mode
  const profile = NEN_PRESENTATION[technique]
  const now = g.context.currentTime
  const oscillator = g.context.createOscillator()
  const gain = g.context.createGain()
  const lfo = g.context.createOscillator()
  const depth = g.context.createGain()
  oscillator.type = profile.sound.noise > 0.3 ? 'sawtooth' : 'sine'
  oscillator.frequency.value = profile.sound.lowHz
  lfo.frequency.value = profile.pulseHz
  depth.gain.value = 0.0035 * profile.sound.volume
  gain.gain.setValueAtTime(0.0001, now)
  gain.gain.exponentialRampToValueAtTime(
    0.009 * profile.sound.volume,
    now + profile.envelope.attack,
  )
  lfo.connect(depth).connect(gain.gain)
  oscillator.connect(gain).connect(g.muffle)
  oscillator.start(now)
  lfo.start(now)
  return () => {
    releaseNenPerception()
    const stopAt = g.context.currentTime + profile.envelope.release
    gain.gain.cancelScheduledValues(g.context.currentTime)
    gain.gain.setValueAtTime(Math.max(0.0001, gain.gain.value), g.context.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.0001, stopAt)
    oscillator.stop(stopAt + 0.02)
    lfo.stop(stopAt + 0.02)
  }
}
