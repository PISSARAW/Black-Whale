const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/EffectComposer-Bf2wPdXp.js","assets/index-15tfLLTl.js","assets/index-CtAd5lBb.css","assets/CopyShader-BzTUYzf6.js","assets/ShaderPass-CEeNxULf.js","assets/Pass-D-6Bakr-.js","assets/UnrealBloomPass-Bit857vY.js","assets/OutputPass-CoEcCiMG.js"])))=>i.map(i=>d[i]);
import{_ as i}from"./index-15tfLLTl.js";const P=.42,R=.55,h=.96,C=.34,_={name:"ClashVignette",uniforms:{tDiffuse:{value:null},amount:{value:C}},vertexShader:`
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,fragmentShader:`
    uniform sampler2D tDiffuse;
    uniform float amount;
    varying vec2 vUv;
    void main() {
      vec4 frame = texture2D(tDiffuse, vUv);
      vec2 offset = vUv - 0.5;
      float edge = smoothstep(0.28, 0.82, length(offset * vec2(1.0, 0.82)));
      gl_FragColor = vec4(frame.rgb * (1.0 - edge * amount), frame.a);
    }
  `},O={name:"ClashSanitise",uniforms:{tDiffuse:{value:null}},vertexShader:_.vertexShader,fragmentShader:`
    uniform sampler2D tDiffuse;
    varying vec2 vUv;
    void main() {
      vec3 frame = texture2D(tDiffuse, vUv).rgb;
      bool sound = frame.r == frame.r && frame.g == frame.g && frame.b == frame.b;
      gl_FragColor = vec4(sound ? clamp(frame, 0.0, 8.0) : vec3(0.0), 1.0);
    }
  `};async function y(a){const{THREE:e,renderer:o,scene:f,camera:l}=a,[{EffectComposer:c},{UnrealBloomPass:u},{ShaderPass:v},{OutputPass:T}]=await Promise.all([i(()=>import("./EffectComposer-Bf2wPdXp.js"),__vite__mapDeps([0,1,2,3,4,5])),i(()=>import("./UnrealBloomPass-Bit857vY.js"),__vite__mapDeps([6,1,2,5,3])),i(()=>import("./ShaderPass-CEeNxULf.js"),__vite__mapDeps([4,1,2,5])),i(()=>import("./OutputPass-CoEcCiMG.js"),__vite__mapDeps([7,1,2,5]))]),s=new e.WebGLRenderTarget(1,1,{type:e.HalfFloatType,samples:a.samples??4}),E=new e.WebGLRenderTarget(1,1,{type:e.HalfFloatType,depthBuffer:!1}),t=new c(o,E),d=new v(O,"composerInput");d.uniforms.tDiffuse.value=s.texture;const n=new u(new e.Vector2(1,1),P,R,h);[n.renderTargetBright,...n.renderTargetsHorizontal,...n.renderTargetsVertical].forEach(r=>{r.depthBuffer=!1});const D=new v(_),S=new T,g=[d,n,D,S];return g.forEach(r=>t.addPass(r)),{render:()=>{I({renderer:o,scene:f,camera:l,target:s}),t.render()},resize:(r,p,m)=>{t.setPixelRatio(m),t.setSize(r,p),s.setSize(r*m,p*m)},dispose:()=>{g.forEach(r=>r.dispose()),t.dispose(),s.dispose()}}}function I(a){const{renderer:e,scene:o,camera:f,target:l}=a,c=e.getRenderTarget(),u=e.autoClear;try{e.autoClear=!1,e.setRenderTarget(l),e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(o,f)}finally{e.autoClear=u,e.setRenderTarget(c)}}export{y as createStagePost};
//# sourceMappingURL=stagePost-DoSR6PKU.js.map
